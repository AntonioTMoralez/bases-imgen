<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>Tables</title>

    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>
<div class="login-logo">
                      <h3 style="margin: 30px; position: inherit; padding: 10px">Libros-Pedidos</h3>
                        </div>
<body class="animsition">
    <div class="page-wrapper">

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="table-responsive table--no-card m-b-30">


                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr>
                                                <th>Id docuemento</th>
                                                <th>Titulo</th>
                                                <th>autores</th>
                                                <th class="text-right">ISBN</th>
                                                <th class="text-right">Solicitado</th>
                                                <th class="text-right">Proveedor</th>
                                                <th class="text-right">Pedido</th>
                                                <th class="text-right">recibido</th>
                                                <th class="text-right">Precio</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                           <tr>


                                             <?php

                                            include 'conexion.php';

                                             				$query="SELECT B.id_documento, B.titulo, B.autor, B.ISBN, B.pedido, B.recibido, B.precio, A.nombres, C.empresa
                                             						FROM usuarios A
                                             						INNER JOIN lbros_pedidos B ON A.id_lector = B.Solicitado_por
                                             						INNER JOIN proveedores C  ON C.NIF = B.Proveedor";

                                             				$consulta=$conexion->query($query);
                                             				while ($fila=$consulta->fetch(PDO::FETCH_ASSOC))
                                             					{
                                             						echo'
                                             						<tr>
                                             						<td>'.$fila['id_documento'].'</td>
                                             						<td>'.$fila['titulo'].'</td>
                                             						<td>'.$fila['autor'].'</td>
                                             						<td>'.$fila['ISBN'].'</td>
                                                        <td>'.$fila['nombres'].'</td>
                                                        <td>'.$fila['empresa'].'</td>
                                                        <td>'.$fila['pedido'].'</td>
                                                        <td>'.$fila['recibido'].'</td>
                                                        <td>'.$fila['precio'].'</td>

                                             						</tr>
                                             						';
                                             					}


                                             				?>
                                           </tr>


                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <!-- USER DATA-->
                            <a href="#" class="btn btn-black">Regresar a inicio</a>
                                <!-- END USER DATA-->
                            </div>

                        </div>


                        <div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p>Copyright © 2020 <a href="https://colorlib.com">By The moralez</a>.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>
<!-- end document-->
