<!DOCTYPE html>
<html lang="es">

    <!-- Basic -->
    <meta charset="utf-8">


    <!-- Mobile Metas -->
     	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

     <!-- Site Metas -->
    <title>Biblioteca</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
   

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">
	<script src="js/modernizr.js"></script> <!-- Modernizr -->

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body id="page-top" class="politics_version">
  <div id="particles-js"></div>

<audio src="audio/Martin%20Garrix%20-%20Poison%20(Extended%20Mix)%20(4401422_409962758).mp3" preload="none" controls autoplay loop hidden="true" volumen="50%"></audio>










	<section id="home" class="main-banner parallaxie" style="background: url('img/fondo4.jpg')">
		<div class="heading">
			<h1>Biblioteca</h1>
			<h3 class="cd-headline clip is-full-width">
				<span><a style="background-color:#46E057; color:#fffffff;font-size: 17px;" class="learn_btn hvr-bounce-to-top" href="Usuarios.php">Ver tablas</a></span>

				<div class="btn-ber">
					<a class="get_btn hvr-bounce-to-top" href="UsuariosFor.php">Usuarios</a>
					
					<a class="learn_btn hvr-bounce-to-top" href="Libros_pedidosFor.php">Libros-pedidos</a>
					
					<a class="get_btn hvr-bounce-to-top" href="ProveedoresFor.php">Proveedores</a>







				</div>
			</h3>
	
    </div>
    </section>

    <!-- ALL JS FILES -->
    <script src="js/all.js"></script>
    <script src="js/particles.min.js"></script>
    <script src="js/app.js"></script>
	<!-- Camera Slider -->
	<script src="js/jquery.mobile.customized.min.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/parallaxie.js"></script>
	<script src="js/headline.js"></script>
	<!-- Contact form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/custom.js"></script>
    <script src="js/jquery.vide.js"></script>

</body>
</html>
