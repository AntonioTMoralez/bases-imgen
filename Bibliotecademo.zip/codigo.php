<?php
header("Content-disposition: attachment; filename=codigo.zip");
header("Content-type: application/zip");
readfile("zip/codigo.zip");
?>